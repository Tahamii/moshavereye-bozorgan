# Moshavereye Bozorgan
"Moshavereye Bozorgan" is an academic project for learning PHP basic concepts. The complete project can be found in [here](https://moshavereye-bozorgan.herokuapp.com/).
